@section('title', 'Reservation')
<x-admin-layout>
    <div class="bg-white p-5 rounded-lg shadow-xl">
        <livewire:admin.reservation-list />
    </div>
</x-admin-layout>
