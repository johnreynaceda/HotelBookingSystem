<div>
    <?php echo e($this->table); ?>

</div>
<?php /**PATH C:\xampp\htdocs\PROJECTS\HotelBookingSystem\resources\views/livewire/admin/user-list.blade.php ENDPATH**/ ?>