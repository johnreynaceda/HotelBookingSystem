<div>
    <?php echo e($this->table); ?>


    <?php if (isset($component)) { $__componentOriginal7ea8362733ae9e02c43079506217fb0f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7ea8362733ae9e02c43079506217fb0f = $attributes; } ?>
<?php $component = WireUi\View\Components\Modal::resolve(['align' => 'center'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(WireUi\View\Components\Modal::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:model.defer' => 'view_modal']); ?>
        <?php if (isset($component)) { $__componentOriginal526977d3da1dbf047bef54116d3416a0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal526977d3da1dbf047bef54116d3416a0 = $attributes; } ?>
<?php $component = WireUi\View\Components\Card::resolve(['title' => 'View Details'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(WireUi\View\Components\Card::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
            <div class="p-5 grid grid-cols-2 gap-5">
                <div>
                    <h1 class=" text-xs font-semibold uppercase">Fullname</h1>
                    <h1><?php echo e($reservation_data->fullname ?? ''); ?></h1>
                </div>
                <div>
                    <h1 class=" text-xs font-semibold uppercase">Address</h1>
                    <h1><?php echo e($reservation_data->address ?? ''); ?></h1>
                </div>
                <div>
                    <h1 class=" text-xs font-semibold uppercase">contact</h1>
                    <h1><?php echo e($reservation_data->contact ?? ''); ?></h1>
                </div>
                <div>
                    <h1 class=" text-xs font-semibold uppercase">email</h1>
                    <h1><?php echo e($reservation_data->email ?? ''); ?></h1>
                </div>
                <div>
                    <h1 class=" text-xs font-semibold uppercase">social media</h1>
                    <h1><?php echo e($reservation_data->social_media ?? ''); ?></h1>
                </div>
                <div>
                    <h1 class=" text-xs font-semibold uppercase">date from</h1>
                    <h1><?php echo e(\Carbon\Carbon::parse($reservation_data->date_from ?? '')->format('F d, Y')); ?></h1>
                </div>
                <div>
                    <h1 class=" text-xs font-semibold uppercase">date to</h1>
                    <h1><?php echo e(\Carbon\Carbon::parse($reservation_data->date_to ?? '')->format('F d, Y')); ?></h1>
                </div>
                <div>
                    <h1 class=" text-xs font-semibold uppercase">room</h1>
                    <h1><?php echo e($reservation_data->room->name ?? ''); ?></h1>
                </div>
                <div>
                    <h1 class=" text-xs font-semibold uppercase">mode of payment</h1>
                    <h1><?php echo e($reservation_data->mode_of_payment ?? ''); ?></h1>
                </div>
                <div>
                    <h1 class=" text-xs font-semibold uppercase">payment status</h1>
                    <h1><?php echo e($reservation_data->status_of_payment ?? ''); ?></h1>
                </div>
                <div>
                    <h1 class=" text-xs font-semibold uppercase">proof of payment</h1>


                    <!--[if BLOCK]><![endif]--><?php if($reservation_data->payment_proof ?? ''): ?>
                        <a href="<?php echo e(Storage::url($reservation_data->payment_proof ?? '')); ?>" target="_blank">
                            <img src="<?php echo e(Storage::url($reservation_data->payment_proof ?? '')); ?>" alt="">
                        </a>
                    <?php else: ?>
                        <h1 class="text-sm text-red-500">No proof of payment because the transaction is WALK IN</h1>
                    <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
                </div>
            </div>

             <?php $__env->slot('footer', null, []); ?> 
                <div class="flex justify-end gap-x-4">
                    <?php if (isset($component)) { $__componentOriginal53cf851b4d6af185b0b5e0467ca69b92 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal53cf851b4d6af185b0b5e0467ca69b92 = $attributes; } ?>
<?php $component = WireUi\View\Components\Button::resolve(['flat' => true,'label' => 'Cancel'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(WireUi\View\Components\Button::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['x-on:click' => 'close']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal53cf851b4d6af185b0b5e0467ca69b92)): ?>
<?php $attributes = $__attributesOriginal53cf851b4d6af185b0b5e0467ca69b92; ?>
<?php unset($__attributesOriginal53cf851b4d6af185b0b5e0467ca69b92); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal53cf851b4d6af185b0b5e0467ca69b92)): ?>
<?php $component = $__componentOriginal53cf851b4d6af185b0b5e0467ca69b92; ?>
<?php unset($__componentOriginal53cf851b4d6af185b0b5e0467ca69b92); ?>
<?php endif; ?>
                </div>
             <?php $__env->endSlot(); ?>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal526977d3da1dbf047bef54116d3416a0)): ?>
<?php $attributes = $__attributesOriginal526977d3da1dbf047bef54116d3416a0; ?>
<?php unset($__attributesOriginal526977d3da1dbf047bef54116d3416a0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal526977d3da1dbf047bef54116d3416a0)): ?>
<?php $component = $__componentOriginal526977d3da1dbf047bef54116d3416a0; ?>
<?php unset($__componentOriginal526977d3da1dbf047bef54116d3416a0); ?>
<?php endif; ?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7ea8362733ae9e02c43079506217fb0f)): ?>
<?php $attributes = $__attributesOriginal7ea8362733ae9e02c43079506217fb0f; ?>
<?php unset($__attributesOriginal7ea8362733ae9e02c43079506217fb0f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7ea8362733ae9e02c43079506217fb0f)): ?>
<?php $component = $__componentOriginal7ea8362733ae9e02c43079506217fb0f; ?>
<?php unset($__componentOriginal7ea8362733ae9e02c43079506217fb0f); ?>
<?php endif; ?>
</div>
<?php /**PATH C:\xampp\htdocs\PROJECTS\HotelBookingSystem\resources\views/livewire/admin/reservation-list.blade.php ENDPATH**/ ?>