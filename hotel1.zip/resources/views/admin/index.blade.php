@section('title', 'Dashboard')
<x-admin-layout>
    <div>
        content here....
    </div>
</x-admin-layout>
