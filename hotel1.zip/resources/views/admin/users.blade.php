@section('title', 'Users')
<x-admin-layout>
    <div class="bg-white p-5 rounded-lg shadow-xl">
        <livewire:admin.user-list />
    </div>
</x-admin-layout>
