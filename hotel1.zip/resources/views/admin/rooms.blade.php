@section('title', 'Rooms')
<x-admin-layout>
    <div class="bg-white p-5 rounded-lg shadow-xl">
        <livewire:admin.room-list />
    </div>
</x-admin-layout>
