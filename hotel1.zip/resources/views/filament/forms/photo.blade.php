<div wire:ignore>
    <img src="{{ Storage::url($this->update_photo->photo_path ?? '') }}" class="h-40 w-64  object-cover" alt="">
</div>
