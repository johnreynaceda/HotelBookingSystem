<a href="{{ Storage::url($getRecord()->photo_path) }}" target="_blank" class="">
    <img src="{{ Storage::url($getRecord()->photo_path) }}" class="ml-3  rounded h-12 w-12 object-cover" alt="">
</a>
